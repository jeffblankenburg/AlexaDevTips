const HelpIntent = require("./HelpIntent");
const RepeatIntent = require("./RepeatIntent");
const StopIntent = require("./StopIntent");

module.exports = {
  HelpIntent,
  RepeatIntent,
  StopIntent,
};
