const getEmail = require("./getEmail");
const getName = require("./getName");
const sendPermissionsCard = require("./sendPermissionsCard");

module.exports = {
  getEmail,
  getName,
  sendPermissionsCard,
};
