const launchRequestHandler = require("../handler/launchRequest");

describe("validate", () => {
  it("no phone number", () => {
    expect(true).toBeTrue();
  });
});
